# AgriNova — Website demo

## Chạy thử trên máy
1. Giải nén toàn bộ source.
2. Mở terminal tại thư mục chứa `index.html`.
3. Chạy `python -m http.server 8080` (hoặc một local static server tương đương).
4. Mở `http://localhost:8080`.

Không nên chỉ mở từng file HTML bằng trình xem Library nếu nơi xem không hỗ trợ đầy đủ asset tương đối và JavaScript. Khi triển khai GitHub Pages, upload **nội dung** thư mục này vào root repository.

## GitHub Pages (tĩnh)
- `index.html` phải nằm tại root repository.
- Trong Settings → Pages, chọn branch `main` và thư mục `/(root)`.
- Website có chatbot fallback theo intent/FAQ, hiểu một số cách viết tắt/teen code; dữ liệu giỏ hàng/tài khoản demo lưu trong trình duyệt và không đồng bộ giữa thiết bị.
- GitHub Pages không thực thi `api/chat.js`, nên không bật AI tạo sinh tùy ý nếu chỉ deploy GitHub Pages.

## Bật AI API thật (tùy chọn, dùng Vercel)
1. Đưa cùng source lên Vercel.
2. Trong Project Settings → Environment Variables, thêm `OPENAI_API_KEY` (secret) và tùy chọn `OPENAI_MODEL`.
3. Redeploy. Chatbot tự dùng `/api/chat` khi hostname là Vercel; nếu host khác, đặt giá trị `content` của `<meta name="agrinova-chat-api">` thành URL API HTTPS của bạn.
4. Tuyệt đối không nhúng API key vào HTML/JS phía trình duyệt, GitHub hoặc repository công khai.

## SEO
- Bài Cẩm nang có title, meta description, canonical, Open Graph/Twitter, H1 duy nhất, heading hierarchy, Article/Breadcrumb structured data, nội dung thực hành và liên kết nội bộ.
- Đã thêm URL bài vào `sitemap.xml`. Khi đổi domain/repository, cập nhật canonical, sitemap, robots và các URL tuyệt đối trong structured data.
- Không thể bảo đảm vị trí #1 Google chỉ bằng source code; cần nội dung có ích, dữ liệu doanh nghiệp xác thực, hiệu suất tốt, liên kết uy tín và theo dõi Search Console theo thời gian.

## Trước khi vận hành thật
- Thay dữ liệu demo về giá, tồn kho, chính sách, địa chỉ, hotline, social và thông tin pháp lý bằng dữ liệu đã xác nhận.
- Thêm backend/cơ sở dữ liệu để xác thực tài khoản, quản lý đơn hàng, đồng bộ giỏ hàng và lưu đánh giá/ảnh/video an toàn.
- Kiểm thử form, chính sách quyền riêng tư, quyền truy cập và tải lên tệp trước khi công khai.


## Bản cập nhật Đăng nhập / Đăng ký / Thanh toán

- Trang `dang-nhap/` và `dang-ky/` dùng bố cục hai cột sáng hiện đại, minh họa cây non SVG và lá rơi bằng CSS; có hỗ trợ `prefers-reduced-motion`.
- Đăng ký kiểm tra độ dài mật khẩu tối thiểu 8 ký tự và xác nhận mật khẩu trùng khớp. Lưu ý: xác thực hiện vẫn là demo dựa trên trình duyệt/localStorage, chưa phải hệ thống tài khoản bảo mật production.
- Trang `thanh-toan/` có COD, chuyển khoản VietinBank, MoMo và ZaloPay. Khi chọn phương thức điện tử, VietQR được tạo theo tổng tiền trong giỏ và nội dung `AGRINOVA <mã đơn>`.
- Thông tin nhận tiền theo yêu cầu: VietinBank, số tài khoản `10987771884`, chủ tài khoản `VO HOAN KHANG`.
- QR được tạo qua Quick Link VietQR (cần kết nối Internet). QR hiện tại là QR chuyển khoản ngân hàng VietinBank, không phải QR merchant riêng của MoMo/ZaloPay. Để thu tiền trực tiếp bằng QR ví chính thức, cần merchant QR/API và backend từ từng nhà cung cấp. Trang demo không xác minh tiền về tài khoản tự động; cần đối soát giao dịch trước khi xác nhận thanh toán.

## Chạy thử local

Mở terminal tại thư mục gốc source và chạy `python -m http.server 8000`; sau đó mở `http://localhost:8000/`. Cách này tránh một số giới hạn của việc mở file HTML trực tiếp.

## Cập nhật luồng thanh toán & trang xác thực

- `dang-nhap/` và `dang-ky/`: bố cục hai cột màu xanh–kem, chuyển động vào trang nhẹ, 8 chiếc lá rơi bằng CSS; tôn trọng `prefers-reduced-motion`.
- `thanh-toan/`: phương thức COD, chuyển khoản VietinBank, MoMo và ZaloPay. Khi chọn phương thức online, mã VietQR được sinh từ tổng giá trị sản phẩm và nội dung chuyển khoản có mã đơn `AGRINOVA AGxxxxxxxx`.
- Sau khi xác nhận đơn online, trang `dat-hang-thanh-cong/` hiển thị lại QR, số tiền, nội dung và thông tin thụ hưởng để người mua không mất mã khi chuyển trang; trạng thái hiển thị là **chờ đối soát**, không tuyên bố đã nhận tiền.
- Tài khoản thụ hưởng theo thông tin được cung cấp: **VietinBank · 10987771884 · VO HOAN KHANG**.
- MoMo/ZaloPay lựa chọn trong demo hiện cùng hiển thị **VietQR chuyển khoản vào ngân hàng**, không phải QR merchant riêng của ví. Muốn thu tiền ví trực tiếp và tự động xác nhận phải đăng ký merchant, tích hợp API/webhook chính thức và backend đối soát.
- VietQR Quick Link cần kết nối Internet. Nếu ảnh QR không tải được, thông tin chuyển khoản vẫn hiển thị để nhập thủ công.
- Trang đăng nhập/đăng ký và luồng đặt hàng vẫn là **demo localStorage**, không phải xác thực tài khoản hoặc xác minh thanh toán production. Không đưa mật khẩu/API key vào localStorage như cơ chế bảo mật thực.


## Bản tinh chỉnh icon, tài khoản và ảnh (2026-10)
- Icon tài khoản dùng SVG người dùng; icon giỏ hàng dùng SVG xe đẩy; mục Trang chủ có biểu tượng ngôi nhà.
- CSS cho tài khoản/giỏ hàng/sản phẩm được nhúng vào trang HTML để tránh lỗi khi mở một file HTML riêng; các stylesheet chuẩn vẫn được giữ để deploy.
- Ảnh sản phẩm hiện ưu tiên các URL ảnh tham khảo nền trắng/nền sáng từ nguồn web, có fallback về ảnh cục bộ nếu nguồn ngoài không tải. Xem `IMAGE-SOURCES.md` để biết danh sách nguồn.
- Ảnh sản phẩm đang là hình minh họa nguồn bên ngoài, một số bao bì không phải SKU AgriNova. Trước production, thay bằng ảnh sản phẩm thật mà doanh nghiệp có quyền sử dụng.
- Banner mùa vụ mới dùng ảnh nền đồng ruộng từ Unsplash với lớp phủ xanh và CTA HTML/CSS.
- Popup homepage dùng placeholder `assets/images/popup-promo-placeholder.svg`; để thay, tải ảnh của bạn vào `assets/images/` rồi cập nhật `src` trong `index.html`.


## Hình ảnh đã được rà soát lại
- Banner trang chủ dùng ảnh nông nghiệp chất lượng cao, không còn ảnh chụp bảng UI/mẫu thiết kế.
- Ảnh thẻ danh mục, thẻ sản phẩm, gallery chi tiết, bài viết và dự án đã được chuyển sang tài nguyên local phù hợp nội dung; không dùng ảnh trang web khác làm ảnh sản phẩm.
- Ảnh sản phẩm là packshot minh họa được tạo cho bản demo; thay bằng ảnh SKU được doanh nghiệp duyệt trước khi bán hàng thật.


## Bản xem trước có ảnh nhúng
- `index.html` và `PREVIEW-TRANG-CHU.html` đã nhúng trực tiếp ảnh/banner tĩnh của trang chủ, vì vậy ảnh trang chủ vẫn xuất hiện khi xem file đơn lẻ.
- Các trang con vẫn dùng tài nguyên chung trong `assets/`; để toàn website hoạt động, hãy chọn **Extract All/Giải nén tất cả** trước khi chạy hoặc tải toàn bộ nội dung lên GitHub. Không mở HTML bên trong cửa sổ ZIP nén.
- Ảnh banner trang chủ: `assets/images/hero-home.jpg`; banner mùa vụ: `assets/images/banner-mua-vu.jpg`; ảnh packshot sản phẩm có tiền tố `product-`.


## Popup ưu đãi thành viên mới
Đã thay placeholder bằng `assets/images/popup-uu-dai-thanh-vien-moi.png`, giữ nền trong suốt, hiển thị không crop ảnh và link tới trang đăng ký. File `PREVIEW-TRANG-CHU.html` nhúng sẵn ảnh để xem độc lập; bản website chính dùng asset local.


## Ảnh Cẩm nang / Blog

Ảnh các bài viết đã được gắn theo từng chủ đề từ Unsplash; xem `IMAGE-SOURCES-BLOG.md` để tra tác giả và trang nguồn của từng ảnh.
