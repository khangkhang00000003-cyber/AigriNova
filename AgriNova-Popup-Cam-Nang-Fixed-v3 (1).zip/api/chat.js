module.exports = async function handler(req, res) {
  const origin = req.headers.origin;
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim();
  const allowed = String(process.env.CHAT_ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
  let sameOrigin = false;
  try { sameOrigin = !!origin && new URL(origin).host === host; } catch (_) {}
  const originAllowed = !origin || sameOrigin || allowed.includes(origin);
  if (origin && originAllowed) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  }
  if (!originAllowed) return res.status(403).json({ error: 'Origin not allowed' });
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const key = process.env.OPENAI_API_KEY;
  if (!key) return res.status(503).json({ error: 'AI endpoint is not configured' });
  const body = req.body || {};
  const message = typeof body.message === 'string' ? body.message.trim().slice(0, 4000) : '';
  if (!message) return res.status(400).json({ error: 'Missing message' });
  const history = Array.isArray(body.history) ? body.history.slice(-8).map(x => ({ role: x && x.role === 'assistant' ? 'assistant' : 'user', content: String(x && x.content || '').slice(0, 2000) })) : [];
  const instructions = `Bạn là AgriBot, trợ lý hỗ trợ khách hàng của AgriNova, một website demo về sản phẩm và kiến thức nông nghiệp tại Việt Nam. Trả lời tiếng Việt tự nhiên, gần gũi, rõ ràng; cố gắng hiểu tiếng Việt không dấu, lỗi chính tả, viết tắt và teen code (vd: ko, k, hok, mik, sp, ib). Nếu câu hỏi mơ hồ, hãy hỏi 1-2 câu làm rõ thay vì đoán. Không bịa giá tồn kho, mã vận đơn, trạng thái đơn, địa chỉ, chứng nhận, cam kết giao hàng, thông số hoặc chính sách không có dữ liệu. Nếu người dùng hỏi đơn hàng, nói rõ bạn không thể truy cập dữ liệu giao dịch thực từ website demo; hướng dẫn vào trang tra cứu hoặc liên hệ nhân viên. Với vấn đề nông học, đưa hướng dẫn tổng quát có điều kiện, lưu ý phụ thuộc giống/địa phương/điều kiện vườn; không chẩn đoán chắc chắn chỉ từ mô tả. Với thuốc bảo vệ thực vật, không tự đưa liều pha chế khi không đủ nhãn; luôn yêu cầu đọc nhãn hợp pháp, đúng cây trồng, đồ bảo hộ và thời gian cách ly. Không khẳng định AgriNova đã cung cấp dịch vụ, giấy phép, chứng nhận hay sản phẩm không được xác nhận. Khi cần báo giá/doanh nghiệp, hướng dẫn người dùng tới trang yêu cầu báo giá; khi cần tư vấn người thật, hướng dẫn trang Liên hệ. Không yêu cầu mật khẩu, OTP, thông tin thẻ hoặc dữ liệu nhạy cảm. Trả lời ngắn gọn trước, sau đó thêm bước thực hiện nếu hữu ích.`;
  const input = [...history, { role: 'user', content: message }];
  try {
    const response = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: process.env.OPENAI_MODEL || 'gpt-6-astra', instructions, input, max_output_tokens: 700, store: false })
    });
    const data = await response.json();
    if (!response.ok) return res.status(502).json({ error: 'AI provider error' });
    let reply = typeof data.output_text === 'string' ? data.output_text : '';
    if (!reply && Array.isArray(data.output)) reply = data.output.flatMap(o => Array.isArray(o.content) ? o.content : []).filter(c => c.type === 'output_text').map(c => c.text).join('\n');
    if (!reply) return res.status(502).json({ error: 'Empty AI response' });
    return res.status(200).json({ reply: reply.slice(0, 7000) });
  } catch (err) { return res.status(502).json({ error: 'Could not reach AI provider' }); }
};
