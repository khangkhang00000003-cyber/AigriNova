# AgriNova Journal — ảnh minh họa

Để tránh lỗi CDN, các bài Cẩm nang hiện dùng ảnh được đóng gói sẵn trong `assets/images/`. Một số ảnh là hình minh họa sản phẩm/vườn canh tác của bản demo; cần thay bằng ảnh thực tế có quyền sử dụng trước khi vận hành thương mại.

- **cach-chon-hat-giong-rau-phu-hop-cho-vuon-nha**: `assets/images/product-khay-hat-giong-rau-mam.webp` — Khay cây con xanh non chuẩn bị gieo trồng.
- **dat-tot-la-nen-tang-cua-mot-vuon-cay-khoe**: `assets/images/product-gia-the-trong-cay-agrinova-20l.webp` — Giá thể trồng cây và đất trồng.
- **quy-trinh-chon-vat-tu-cay-trong-cho-doanh-nghiep**: `assets/images/article-doanh-nghiep.jpg` — Vườn canh tác minh họa quy trình chọn vật tư cho doanh nghiệp.
- **5-buoc-cham-soc-cay-trong-giai-doan-ra-hoa**: `assets/images/product-hat-giong-ca-chua-bi-do-f1.webp` — Cây cà chua minh họa chăm sóc cây trong giai đoạn ra hoa.
- **cach-gieo-hat-rau-tai-nha**: `assets/images/product-hat-giong-rau-an-la-f1.webp` — Hạt giống rau ăn lá chuẩn bị gieo trồng.
- **cach-tron-dat-trong-rau-trong-chau**: `assets/images/product-phan-huu-co-20kg.webp` — Phân hữu cơ dùng để cải tạo đất trồng.
- **cach-tuoi-nuoc-cho-rau-dung-cach**: `assets/images/project-greenhouse.jpg` — Vườn rau trong nhà kính.
- **cach-bon-phan-huu-co-cho-rau**: `assets/images/product-phan-huu-co-agrinova-green-5kg.webp` — Bao phân hữu cơ AgriNova Green.
- **huong-dan-chon-gia-the-cho-rau-an-la**: `assets/images/product-gia-the-trong-cay-agrinova-20l.webp` — Giá thể trồng rau trong chậu.
- **nhan-biet-sau-benh-tren-rau-va-xu-ly-an-toan**: `assets/images/product-dung-dich-bao-ve-sinh-hoc.webp` — Sản phẩm hỗ trợ bảo vệ cây trồng.
