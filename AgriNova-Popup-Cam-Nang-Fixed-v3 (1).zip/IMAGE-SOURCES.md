# AgriNova — nguồn ảnh tham khảo

Bộ ảnh sản phẩm trong bản demo trỏ tới ảnh sản phẩm nền trắng/nền sáng lấy từ các trang công khai bên dưới. Đây là **ảnh tham khảo để demo giao diện**, một số bao bì mang nhãn hiệu của nhà bán hàng khác và không phải cam kết đó là bao bì thật của AgriNova. Trước khi website hoạt động thương mại, hãy thay bằng ảnh SKU thực tế do doanh nghiệp sở hữu hoặc có giấy phép sử dụng.

## Ảnh sản phẩm nền trắng
- Hạt giống cà chua (ảnh gói hạt): https://krishibazaar.in/public/frontend/images/product-img/PHXDh1734073462.jpg
- Cây giống họ cam chanh: https://www.seedeo.de/products/seedeo%C2%AE-yuzu-zitrone-citrus-junos-yuzu-pflanze-ca-15-cm-hoch
- Phân hữu cơ (bao 5 kg tham khảo): https://www.oleandershop.de/compo-bio-organischer-gartenduenger-5-kg_27241_27577
- Giá thể/đất trồng (bao tham khảo): https://www.truevalue.com/product/704286/schultz-premium-1-cu-ft-all-purpose-indoor-outdoor-potting-soil-plus-704286/
- Bình xịt làm vườn trên nền trắng: https://www.pexels.com/photo/green-spray-bottle-on-white-surface-5217884/
- Hạt giống rau ăn lá: https://shopee.com.my/Serbajadi-Lettuce-Daun-Salad-Vegetable-Seeds-%E7%A7%8D%E5%AD%90-BBS012-i.9808190.709862752
- Phân hữu cơ dạng bao: https://plantaddicts.com/natures-supreme-organic-all-purpose-fertilizer/
- Khay rau mầm: https://www.harrisseeds.com/products/41800-no-drainage-microgreen-growing-trays
- Khay rau mầm bổ sung: https://bageechabox.com/products/seed-tray-1010-extra-strength

## Banner
- Ảnh nền đồng ruộng từ Unsplash License: https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=2000&q=85
- Banner được dàn trang bằng HTML/CSS của AgriNova (tiêu đề, CTA, lớp phủ màu xanh), không phải ảnh quảng cáo được ghép chữ sẵn.

## Popup
- Ảnh placeholder: `assets/images/popup-promo-placeholder.svg`. Khi có ảnh riêng, lưu ảnh mới trong `assets/images/` và đổi `src` của popup trong `index.html`.


## Popup ưu đãi thành viên mới (ảnh do chủ website cung cấp)
- File: `assets/images/popup-uu-dai-thanh-vien-moi.png`
- Popup tự hiện sau khoảng 9,5 giây; bấm vào ảnh sẽ mở trang đăng ký, có nút đóng và tùy chọn ẩn trong phiên hiện tại.
