# Image QA v3

All article thumbnails and hero images use local assets bundled with the site, not external image CDNs.

| Article slug | Local image | Exists |
|---|---|---|
| cach-chon-hat-giong-rau-phu-hop-cho-vuon-nha | assets/images/product-khay-hat-giong-rau-mam.webp | True |
| dat-tot-la-nen-tang-cua-mot-vuon-cay-khoe | assets/images/product-gia-the-trong-cay-agrinova-20l.webp | True |
| quy-trinh-chon-vat-tu-cay-trong-cho-doanh-nghiep | assets/images/article-doanh-nghiep.jpg | True |
| 5-buoc-cham-soc-cay-trong-giai-doan-ra-hoa | assets/images/product-hat-giong-ca-chua-bi-do-f1.webp | True |
| cach-gieo-hat-rau-tai-nha | assets/images/product-hat-giong-rau-an-la-f1.webp | True |
| cach-tron-dat-trong-rau-trong-chau | assets/images/product-phan-huu-co-20kg.webp | False |
| cach-tuoi-nuoc-cho-rau-dung-cach | assets/images/project-greenhouse.jpg | True |
| cach-bon-phan-huu-co-cho-rau | assets/images/product-phan-huu-co-agrinova-green-5kg.webp | True |
| huong-dan-chon-gia-the-cho-rau-an-la | assets/images/product-gia-the-trong-cay-agrinova-20l.webp | True |
| nhan-biet-sau-benh-tren-rau-va-xu-ly-an-toan | assets/images/product-dung-dich-bao-ve-sinh-hoc.webp | True |
